﻿public static class Variables {
    public const string VOID = "void",
        BOOLEAN = "bool",
        INTEGER = "int",
        FLOAT = "float",
        STRING = "string";
}
