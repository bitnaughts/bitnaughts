﻿public static class Plotter {
    public const string NAME = "Plotter",
    PLOT = "Plot",
    OPEN = "Open",
    CLOSE = "Close",
    SUBSCRIBE = "Subscribe";
}

