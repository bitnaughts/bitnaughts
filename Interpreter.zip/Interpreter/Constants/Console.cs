﻿public static class Console {
    public const string NAME = "Console",
    WRITE = "Write",
    WRITE_LINE = "WriteLine",
    OPEN = "Open",
    ADD = "Add",
    CLOSE = "Close",
    UPDATE = "Update";


}

