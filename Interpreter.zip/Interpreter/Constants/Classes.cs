﻿public static class Classes {
    
    public const string CONSOLE = "Console",
    PLOTTER = "Plotter";

    // public const string[] ALL_CLASSES = {CONSOLE, PLOTTER};
}
