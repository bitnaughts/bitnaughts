﻿public static class Keywords {
    public const string BREAK = "break;",
        CONTINUE = "continue;",
        IF = "if",
        WHILE = "while",
        FOR = "for",
        STATIC = "static",
        NEW = "new",
        NULL = "null",
        LIBRARY_IMPORT = "using";

    // public const string[] ALL_KEYWORDS = { BREAK, CONTINUE, IF, WHILE, FOR, LIBRARY_IMPORT };
}