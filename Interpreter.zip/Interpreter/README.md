# BitNaughts (Interpreter)

## Examples

Console.Open(this.script);
int i = 0;
if (i < 100) {

    while (i < 200) {
        i++;
        this.
        this.rotation = i;
    }
}



Console.Open(this.script);
int i = 0;
if (i < 100) {
while (i < 200) {
i++;
this.rotation = i;
}
}

//self
this.script
//position
this.position
this.rotation
//this.MissileObject


1 class MissileObject {
2   int angle = 0;
3   Vector2 positon = this.position;
4   Vector2 target = enemies[0].position;
5   while (true) {
6      float angle = Vector2.angle(position,target)
7      this.RotateTowards(angle);
8   }
9 }
