﻿using UnityEngine;
using System.Collections;

public class ShipSize : MonoBehaviour 
{
	public Vector2 size;
}
