﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
public class test : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		//this.GetComponent<Text>().text = (Input.GetTouch(0).position.x + " " + Input.GetTouch(0).position.y);
	}
}
