﻿using UnityEngine;
using System.Collections;

public class ControllerHolder : MonoBehaviour {
    //  public R
    public RuntimeAnimatorController controller;
}
