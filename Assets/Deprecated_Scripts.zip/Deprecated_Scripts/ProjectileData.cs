﻿
public class ProjectileData
{
    public int team;
    public float speed;
    public float damage;
    public float size;

    public ProjectileData(int team, float speed, float damage, float size)
    {
        this.team = team;
        this.speed = speed;
        this.damage = damage;
        this.size = size;
    }
}
